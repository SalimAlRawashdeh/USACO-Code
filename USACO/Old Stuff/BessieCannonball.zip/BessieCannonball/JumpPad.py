class JumpPad:
    def __init__(jumpPad, power):
        jumpPad.power = power
        jumpPad.type = "jumpPad"

    def getPower(jumpPad):
        return jumpPad.power

    def getType(jumpPad):
        return jumpPad.type