class Ball:
    def __init__(ball, velocity):
        ball.velocity = velocity

    def getVelocity (ball):
        return ball.velocity

    def setVelocity(ball, velocity):
        ball.velocity = velocity